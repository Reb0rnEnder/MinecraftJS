#version 120
uniform sampler2D colortex0;varying vec2 texCoord;void main(){vec4 c=texture2D(colortex0,texCoord);gl_FragColor=c+vec4(.125,0,0,0);}
