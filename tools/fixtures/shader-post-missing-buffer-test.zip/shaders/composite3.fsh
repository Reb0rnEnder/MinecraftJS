#version 120
uniform sampler2D colortex0;varying vec2 texCoord;void main(){gl_FragColor=texture2D(colortex0,texCoord)+vec4(0,.125,0,0);}