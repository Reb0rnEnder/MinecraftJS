#version 120
/* DRAWBUFFERS:3 */
void main(){gl_FragColor=vec4(0);}