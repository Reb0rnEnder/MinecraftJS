#version 120
uniform sampler2D colortex7;varying vec2 texCoord;void main(){gl_FragColor=texture2D(colortex7,texCoord);}