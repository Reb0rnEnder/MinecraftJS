#version 120
uniform sampler2D colortex0;varying vec2 texCoord;void main(){vec4 c=texture2D(colortex0,texCoord);gl_FragColor=vec4(1.0-c.rgb,c.a);}
