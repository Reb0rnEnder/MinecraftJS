vec3 WavingBlocks(vec3 p,int blockID,float top){if(blockID==100 && top>0.9)p.x+=sin(time+p.z)*0.2*ANIMATION_STRENGTH;return p;}
