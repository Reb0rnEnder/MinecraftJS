varying vec2 texCoord;
uniform sampler2D colortex1;
void main(){gl_FragColor=texture2DLod(colortex1,texCoord,0);}
