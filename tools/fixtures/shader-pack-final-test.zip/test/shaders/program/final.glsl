varying vec2 texCoord;
uniform sampler2D colortex0;
void main(){gl_FragColor=texture2DLod(colortex0,texCoord,0);}
