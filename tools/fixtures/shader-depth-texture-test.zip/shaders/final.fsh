#version 120
varying vec2 texCoord;
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D palette;
uniform mat4 gbufferProjectionInverse;
uniform vec2 view_pixel_size;
uniform vec3 cameraPosition;
#define GAIN 1.0 // [0.5 1.0 1.5]
void main(){vec3 scene=texture2D(colortex0,texCoord).rgb;float depth=texture2D(depthtex0,texCoord).r;vec3 tint=texture2D(palette,texCoord).rgb;gl_FragColor=vec4(scene.r*GAIN,depth,tint.b,1.0);}
